# Mahmoud Gym Tracker

تطبيق عربي لمتابعة تمارين الجيم، مبني بـ React + Vite، وجاهز للتحويل إلى تطبيق Android عبر Capacitor.

## ماذا يفعل

- أسبوع من 7 أيام (السبت إلى الجمعة)، ولكل يوم اسم تركيز قابل للتعديل.
- مكتبة أجهزة وتمارين مصنفة حسب العضلة، مع إضافة وتعديل وحذف.
- لكل تمرين مجموعات: وزن بالكيلوجرام، تكرارات، علامة "تمت"، وملاحظة.
- أسبوع جديد بضغطة واحدة ينسخ التمارين وآخر الأوزان، ويبقى سجل الأسابيع السابقة.
- رسم بياني لتطور كل تمرين (أعلى وزن أو الحجم الكلي) وجدول مقارنة بين أي أسبوعين.
- حفظ تلقائي على الجهاز (`localStorage`) ونسخ احتياطي واستعادة بالنسخ واللصق.

> المجموعة تُحتسب في الرسم والمقارنة فقط إذا علّمتها بعلامة ✓.

## هيكل المشروع

```
src/logic.js     منطق البيانات (بدون React): الأسابيع، الإحصائيات، الحفظ
src/App.jsx      الواجهة
src/styles.css   التصميم الأسود والأخضر
tests/           اختبارات المنطق (vitest)
capacitor.config.json   إعداد تطبيق Android
```

## 1) حفظ المشروع وتشغيله على الكمبيوتر

المطلوب: Node.js 18 أو أحدث.

```bash
cd mahmoud-gym-tracker
npm install
npm run dev        # تشغيل للتجربة، افتح الرابط الذي يظهر على الموبايل أو المتصفح
npm test           # اختبارات المنطق
npm run build      # ينتج مجلد dist
```

احفظ المجلد على GitHub أو في أي مكان آمن:

```bash
git init
git add .
git commit -m "Mahmoud Gym Tracker"
```

## 2) تحويل المشروع إلى APK

المطلوب: [Android Studio](https://developer.android.com/studio) (يثبّت معه Android SDK وJDK).

```bash
npm install
npm run android:add     # مرة واحدة: ينشئ مجلد android/
npm run android:sync    # يبني الواجهة وينسخها إلى مشروع Android
npm run android:open    # يفتح Android Studio
```

داخل Android Studio:

1. انتظر حتى ينتهي Gradle من المزامنة.
2. لتجربة سريعة: وصّل هاتفك مع تفعيل "تصحيح USB" أو شغّل محاكيًا، ثم اضغط Run.
3. لملف APK للتثبيت: **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
   ستجد الملف في `android/app/build/outputs/apk/debug/app-debug.apk`. انقله إلى الهاتف وثبّته (يجب السماح بالتثبيت من مصادر غير معروفة).
4. لنسخة موقّعة للنشر أو للتوزيع: **Build ▸ Generate Signed Bundle / APK** وأنشئ مفتاح توقيع (keystore) واحتفظ به في مكان آمن، فبدونه لا يمكنك تحديث التطبيق لاحقًا.

بعد أي تعديل في الكود: `npm run android:sync` ثم أعد التشغيل من Android Studio.

### ملاحظات مهمة

- **اسم الحزمة** `com.mahmoud.gymtracker` في `capacitor.config.json`. غيّره قبل `android:add` إذا أردت اسمًا آخر.
- **الخطوط**: الخطان Changa وIBM Plex Sans Arabic يُحمَّلان من Google Fonts، فيظهران عند وجود إنترنت. دون إنترنت يستخدم التطبيق خط النظام العربي ويعمل بشكل طبيعي. لتضمينهما داخل التطبيق ثبّت `@fontsource/changa` و`@fontsource/ibm-plex-sans-arabic` واستوردهما في `src/main.jsx`.
- **البيانات** تُحفظ في تخزين التطبيق على الهاتف، ولا تُرفع لأي خادم. حذف التطبيق أو مسح بياناته يمسحها، لذلك استخدم "نسخ النسخة الاحتياطية" من تبويب السجل بين وقت وآخر.
- **الأيقونة وشاشة البداية**: الافتراضية هي أيقونة Capacitor. لتغييرها استخدم الأداة `@capacitor/assets` بعد وضع صورة الأيقونة في مجلد `assets/`.
