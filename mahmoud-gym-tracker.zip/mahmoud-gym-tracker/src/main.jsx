import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';

document.documentElement.lang = 'ar';
document.documentElement.dir = 'rtl';

createRoot(document.getElementById('root')).render(<App />);
